<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');

$data = json_decode(file_get_contents("php://input"));

// Debugging: Check the data received
file_put_contents('php://stderr', print_r($data, TRUE));

if (isset($data->auth) && isset($data->playername)) {
    $auth = $data->auth;
    $playername = $data->playername;

    $host = "localhost";
    $user = "root";
    $pass = ""; 
    $db = "indohax";

    $mysqli = new mysqli($host, $user, $pass, $db);

    if ($mysqli->connect_error) {
        die("Database connection failed: " . $mysqli->connect_error);
    }

    // Check if the current playername is the same as the new one
    $check_query = "SELECT playername FROM users WHERE auth = ?";
    $check_stmt = $mysqli->prepare($check_query);
    $check_stmt->bind_param("s", $auth);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        $row = $check_result->fetch_assoc();
        if ($row['playername'] === $playername) {
            echo json_encode([
                'success' => false,
                'message' => 'Player name is already the same'
            ]);
            $check_stmt->close();
            $mysqli->close();
            exit();
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Player not found'
        ]);
        $check_stmt->close();
        $mysqli->close();
        exit();
    }

    $check_stmt->close();

    // Update player's name
    $query = "UPDATE users SET playername = ? WHERE auth = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $playername, $auth);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'Player name updated successfully'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to update player name'
        ]);
    }

    $stmt->close();
    $mysqli->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Missing auth or playername parameter'
    ]);
}
?>
