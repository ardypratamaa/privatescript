<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');

$data = json_decode(file_get_contents("php://input"));

if (isset($data->auth) && isset($data->login_code)) {
    $auth = $data->auth;
    $login_code = $data->login_code;

    $host = "localhost";
    $user = "root";
    $pass = ""; 
    $db = "indohax";

    $mysqli = new mysqli($host, $user, $pass, $db);

    if ($mysqli->connect_error) {
        die("Database connection failed: " . $mysqli->connect_error);
    }

    // Update the login_code in the users table based on auth
    $query = "UPDATE users SET login_code = ? WHERE auth = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("ss", $login_code, $auth);
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Login code updated successfully in users table'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to update login code in users table'
        ]);
    }

    $stmt->close();
    $mysqli->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Missing auth or login_code parameter'
    ]);
}
?>
