<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');

$data = json_decode(file_get_contents("php://input"));

if (isset($data->auth) && isset($data->login_code)) {
    $auth = $data->auth;
    $login_code = $data->login_code;

    $host = "localhost";
    $user = "root";
    $pass = ""; 
    $db = "indohax";

    $mysqli = new mysqli($host, $user, $pass, $db);

    if ($mysqli->connect_error) {
        die("Database connection failed: " . $mysqli->connect_error);
    }

    // Step 1: Check if the login_code already exists in the users table
    $checkQuery = "SELECT auth FROM users WHERE login_code = ?";
    $checkStmt = $mysqli->prepare($checkQuery);
    $checkStmt->bind_param("s", $login_code);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        // Step 2: If exists, update the old auth's login_code to '0'
        $row = $checkResult->fetch_assoc();
        $oldAuth = $row['auth'];

        $updateOldQuery = "UPDATE users SET login_code = '0' WHERE auth = ?";
        $updateOldStmt = $mysqli->prepare($updateOldQuery);
        $updateOldStmt->bind_param("s", $oldAuth);
        $updateOldStmt->execute();
        $updateOldStmt->close();
    }
    $checkStmt->close();

    // Step 3: Update the login_code in the users table based on the current auth
    $updateQuery = "UPDATE users SET login_code = ? WHERE auth = ?";
    $updateStmt = $mysqli->prepare($updateQuery);
    $updateStmt->bind_param("ss", $login_code, $auth);
    
    if ($updateStmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Login code updated successfully in users table'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to update login code in users table'
        ]);
    }

    $updateStmt->close();
    $mysqli->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Missing auth or login_code parameter'
    ]);
}
?>
