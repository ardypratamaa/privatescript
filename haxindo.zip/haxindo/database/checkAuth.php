<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');

$data = json_decode(file_get_contents("php://input"));

if (isset($data->auth)) {
    $auth = $data->auth;

    $host = "localhost";
    $user = "root";
    $pass = ""; 
    $db = "indohax";

    $mysqli = new mysqli($host, $user, $pass, $db);

    if ($mysqli->connect_error) {
        die("Database connection failed: " . $mysqli->connect_error);
    }

    $query = "SELECT * FROM users WHERE auth = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $auth);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode([
            'exists' => true
        ]);
    } else {
        echo json_encode([
            'exists' => false
        ]);
    }

    $stmt->close();
    $mysqli->close();
} else {
    echo json_encode([
        'exists' => false,
        'message' => 'Missing auth parameter'
    ]);
}
?>
