<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');

$data = json_decode(file_get_contents("php://input"));

if (isset($data->auth) && isset($data->stars) && isset($data->goals)) {
    $auth = $data->auth;
    $stars = $data->stars;
    $goals = $data->goals;

    // Additional parameters
    $win = isset($data->win) ? $data->win : 0;
    $lose = isset($data->lose) ? $data->lose : 0;
    $assist = isset($data->assist) ? $data->assist : 0;
    $matchesPlayed = isset($data->matchesPlayed) ? $data->matchesPlayed : 0;
    $cleanSheet = isset($data->cleanSheet) ? $data->cleanSheet : 0;
    $cleanSheetPercentage = isset($data->cleanSheetPercentage) ? $data->cleanSheetPercentage : "0.00";
    // Add more parameters as needed

    $host = "localhost";
    $user = "root";
    $pass = ""; 
    $db = "indohax";

    $mysqli = new mysqli($host, $user, $pass, $db);

    if ($mysqli->connect_error) {
        die("Koneksi database gagal: " . $mysqli->connect_error);
    }

    // Check if auth exists
    $check_query = "SELECT COUNT(*) AS count FROM users WHERE auth = ?";
    $check_stmt = $mysqli->prepare($check_query);
    $check_stmt->bind_param("s", $auth);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    $row = $check_result->fetch_assoc();
    $count = $row['count'];

    if ($count > 0) {
        // Update existing record
        $query = "UPDATE users SET stars = ?, goals = ?, win = ?, lose = ?, assist = ?, matches_played = ?, clean_sheet = ?, clean_sheet_percentage = ? WHERE auth = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("iiiisiiis", $stars, $goals, $win, $lose, $assist, $matchesPlayed, $cleanSheet, $cleanSheetPercentage, $auth);
        $stmt->execute();
    } else {
        // Insert new record
        $query = "INSERT INTO users (auth, stars, goals, win, lose, assist, matches_played, clean_sheet, clean_sheet_percentage) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("siiiiiiis", $auth, $stars, $goals, $win, $lose, $assist, $matchesPlayed, $cleanSheet, $cleanSheetPercentage);
        $stmt->execute();
    }

    if ($stmt->affected_rows > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'Player data updated successfully'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to update player data'
        ]);
    }

    $stmt->close();
    $mysqli->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Missing auth, stars, or goals parameter'
    ]);
}
?>
