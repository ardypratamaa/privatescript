var roomConfig = {
    roomName: "Big Easy | Ranked Match",
    playerName: "Beta|Test",
    maxPlayers: 15,
    public: true
};

var room = HBInit(roomConfig);

var players = {};

function getPlayerById(id) {
    return players[id];
}

function addNewPlayerById(id, auth, stars, goals) {
    players[id] = {
        id: id,
        auth: auth,
        stars: stars,
        goals: goals
    };
}

function checkPlayerInDatabase(auth, callback) {
    var xhr = new XMLHttpRequest();
    var url = 'http://localhost/haxindo/database/getPlayer.php'; 

    xhr.open('POST', url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');

    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                var response = JSON.parse(xhr.responseText);
                if (response.success) {
                    var playerData = response.data;
                    callback(playerData.auth, playerData.stars, playerData.goals);
                } else {
                    callback(null); 
                }
            } else {
                console.error('Terjadi kesalahan: ' + xhr.status);
                callback(null); 
            }
        }
    };

    var data = {
        auth: auth
    };

    xhr.send(JSON.stringify(data));
}

room.onPlayerJoin = function(player) {
    var id = player.id;
    var auth = player.auth;

    checkPlayerInDatabase(auth, function(databaseAuth, databaseStars, databaseGoals) {
        if (databaseAuth) {
            addNewPlayerById(id, databaseAuth, databaseStars, databaseGoals);
            players[id].id = id; 
            console.log("Player " + player.name + " rejoined. Stars: " + databaseStars + " Goals: " + databaseGoals);
            room.sendChat("Selamat datang kembali, " + player.name + "! Anda memiliki " + databaseStars + " Stars dan " + databaseGoals + " Goals.");
        } else {
            addNewPlayerById(id, auth, 10, 0);
            console.log("Player " + player.name + " bergabung untuk pertama kali. Stars: 10 Goals: 0");
            room.sendChat("Selamat datang, " + player.name + "! Anda telah mendapatkan 10 Stars dan 0 Goals.");
        }
    });
}

room.onPlayerChat = function(player, message) {
    if (message === "!loginadmin") {
        room.setPlayerAdmin(player.id, true);
        return false;
    }

    if (message === "!mystar") {
        var currentPlayer = getPlayerById(player.id);

        if (currentPlayer) {
            room.sendChat(player.name + ", kamu memiliki " + currentPlayer.stars + " Stars dan " + currentPlayer.goals + " Goals.");
        } else {
            room.sendChat(player.name + ", kamu belum terdaftar dalam sistem.");
        }

        return false;
    }

    var currentPlayer = getPlayerById(player.id);

    if (!currentPlayer) {
        room.sendChat(player.name + ", kamu belum terdaftar dalam sistem.");
        return false;
    }

    var stars = currentPlayer.stars;
    var announcement = "";
    var chatColor = "";

    if (stars < 10) {
        announcement += "[Dark System]";
        chatColor = "0x030637";
    } else if (stars < 20) {
        announcement += "[Bronze]";
        chatColor = "0xDF943A";
    } else if (stars < 30) {
        announcement += "[Elite]";
        chatColor = "0x73777B";
    } else if (stars < 40) {
        announcement += "[Master]";
        chatColor = "0xD4D925";
    } else if (stars < 50) {
        announcement += "[Grandmaster]";
        chatColor = "0xB3C8CF";
    } else if (stars < 70) {
        announcement += "[Epic]";
        chatColor = "0x75A47F";
    } else if (stars < 80) {
        announcement += "[Legend]";
        chatColor = "0xFFB200";
    } else if (stars < 90) {
        announcement += "[Mythic]";
        chatColor = "0xF8DE22";
    } else if (stars < 100) {
        announcement += "[Glory]";
        chatColor = "0x36C2CE";
    } else {
        announcement += "[Immortal]";
        chatColor = "0xDF2E38";
    }

    console.log(announcement);
    console.log(chatColor);

    announcement += player.name + ": " + message;

    room.sendAnnouncement(announcement, null, parseInt(chatColor));

    return false;
}

function updateStarsAndGoals(winningTeam, losingTeam, goalsScored) {
    winningTeam.forEach(player => {
        var currentPlayer = getPlayerById(player.id);
        currentPlayer.stars += 10 + (goalsScored * 2); 
        room.sendChat("Winner: " + player.name + " (" + currentPlayer.stars + " Stars)");

        sendDataToServer(currentPlayer);
    });

    losingTeam.forEach(player => {
        var currentPlayer = getPlayerById(player.id);
        currentPlayer.stars -= 5; 
        if (currentPlayer.stars < 0) currentPlayer.stars = 0;
        room.sendChat("Loser: " + player.name + " (" + currentPlayer.stars + " Stars)");

        sendDataToServer(currentPlayer);
    });
}

room.onTeamVictory = function(scores) {
    var winningTeam = scores.red > scores.blue ? 1 : 2;
    var losingTeam = winningTeam === 1 ? 2 : 1;

    var winningPlayers = room.getPlayerList().filter(p => p.team === winningTeam);
    var losingPlayers = room.getPlayerList().filter(p => p.team === losingTeam);

    updateStarsAndGoals(winningPlayers, losingPlayers, scores.red + scores.blue);
};

room.onTeamGoal = function(team) {
    var scoringTeam = team;
    var scoringPlayers = room.getPlayerList().filter(p => p.team === scoringTeam);
    
    scoringPlayers.forEach(player => {
        var currentPlayer = getPlayerById(player.id);
        if (currentPlayer) {
            currentPlayer.goals += 1;
            room.sendChat(player.name + " has scored! Total Goals: " + currentPlayer.goals);
            sendDataToServer(currentPlayer);
        }
    });
};

function sendDataToServer(player) {
    var xhr = new XMLHttpRequest();
    var url = 'http://localhost/haxindo/database/updatePlayer.php'; 
        
    var data = {
        auth: player.auth, 
        stars: player.stars,
        goals: player.goals 
    };
    
    xhr.open('POST', url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                console.log(xhr.responseText); 
            } else {
                console.error('Terjadi kesalahan: ' + xhr.status);
            }
        }
    };
    
    xhr.send(JSON.stringify(data));
}