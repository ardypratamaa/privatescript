<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');

$data = json_decode(file_get_contents("php://input"));

if (isset($data->auth) && isset($data->stars)) {
    $auth = $data->auth;
    $stars = $data->stars;
    $win = isset($data->win) ? $data->win : 0;
    $lose = isset($data->lose) ? $data->lose : 0;
    $assist = isset($data->assist) ? $data->assist : 0;
    $matchesPlayed = isset($data->matchesPlayed) ? $data->matchesPlayed : 0;
    $cleanSheet = isset($data->cleanSheet) ? $data->cleanSheet : 0;
    $cleanSheetPercentage = isset($data->cleanSheetPercentage) ? $data->cleanSheetPercentage : "0.00";

    $host = "localhost";
    $user = "root";
    $pass = ""; 
    $db = "indohax";

    $mysqli = new mysqli($host, $user, $pass, $db);

    if ($mysqli->connect_error) {
        die("Database connection failed: " . $mysqli->connect_error);
    }

    // Check if auth exists
    $check_query = "SELECT COUNT(*) AS count FROM users WHERE auth = ?";
    $check_stmt = $mysqli->prepare($check_query);
    $check_stmt->bind_param("s", $auth);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    $row = $check_result->fetch_assoc();
    $count = $row['count'];

    if ($count > 0) {
        // Update existing record
        $query = "UPDATE users SET stars = ?, win = ?, lose = ?, assist = ?, matches_played = ?, clean_sheet = ?, clean_sheet_percentage = ? WHERE auth = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("iiiisiss", $stars, $win, $lose, $assist, $matchesPlayed, $cleanSheet, $cleanSheetPercentage, $auth);
        $stmt->execute();
    } else {
        // Insert new record
        $query = "INSERT INTO users (auth, stars, win, lose, assist, matches_played, clean_sheet, clean_sheet_percentage) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("siiiisis", $auth, $stars, $win, $lose, $assist, $matchesPlayed, $cleanSheet, $cleanSheetPercentage);
        $stmt->execute();
    }

    if ($stmt->affected_rows > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'Player stars and other stats updated successfully'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to update player stars and other stats'
        ]);
    }

    $stmt->close();
    $mysqli->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Missing auth or stars parameter'
    ]);
}
?>
