<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');

$data = json_decode(file_get_contents("php://input"));

if (isset($data->auth) && isset($data->conn)) {
    $auth = $data->auth;
    $conn = $data->conn;

    $host = "localhost";
    $user = "root";
    $pass = ""; 
    $db = "indohax";

    $mysqli = new mysqli($host, $user, $pass, $db);

    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    }

    // Check if the player is already banned
    $checkQuery = "SELECT * FROM banlist WHERE auth = ? OR conn = ?";
    $stmt = $mysqli->prepare($checkQuery);
    $stmt->bind_param("ss", $auth, $conn);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Player is already banned'
        ]);
    } else {
        // Insert the ban record
        $query = "INSERT INTO banlist (auth, conn) VALUES (?, ?)";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("ss", $auth, $conn);

        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Player banned successfully'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to ban player'
            ]);
        }
    }

    $stmt->close();
    $mysqli->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Missing auth or conn parameter'
    ]);
}
?>
