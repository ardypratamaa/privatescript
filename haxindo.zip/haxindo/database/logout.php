<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');

$data = json_decode(file_get_contents("php://input"));

if (isset($data->auth)) {
    $auth = $data->auth;

    $host = "localhost";
    $user = "root";
    $pass = ""; 
    $db = "indohax";

    $mysqli = new mysqli($host, $user, $pass, $db);

    if ($mysqli->connect_error) {
        die("Database connection failed: " . $mysqli->connect_error);
    }

    // Check if the player's auth exists in the users table
    $query = "SELECT login_code FROM users WHERE auth = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $auth);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $login_code = $row['login_code'];

        // Update login_status to "no" in the account table
        $query = "UPDATE account SET login_status = 'no' WHERE login_code = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("s", $login_code);

        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'You have been logged out successfully.'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Failed to log out.'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Auth not found in users table.'
        ]);
    }

    $stmt->close();
    $mysqli->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Missing auth parameter.'
    ]);
}
?>
