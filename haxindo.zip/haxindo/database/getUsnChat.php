<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');

// Read input data from the request
$data = json_decode(file_get_contents("php://input"));

// Check if auth is provided
if (isset($data->auth)) {
    $auth = $data->auth;

    // Database connection settings
    $host = "localhost";
    $user = "root";
    $pass = ""; 
    $db = "indohax";

    // Create a new MySQLi connection
    $mysqli = new mysqli($host, $user, $pass, $db);

    // Check connection
    if ($mysqli->connect_error) {
        die(json_encode([
            'success' => false,
            'message' => 'Database connection failed: ' . $mysqli->connect_error
        ]));
    }

    // Check if the player's auth exists in the users table
    $query = "SELECT login_code FROM users WHERE auth = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $auth);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $login_code = $row['login_code'];

        // Check if the login_code exists in the account table and get the username and login_status
        $query = "SELECT username, login_status FROM account WHERE login_code = ?";
        $stmt = $mysqli->prepare($query);
        $stmt->bind_param("s", $login_code);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $username = $row['username'];
            $login_status = $row['login_status'];

            if ($login_status === 'no') {
                echo json_encode([
                    'success' => false,
                    'message' => 'User is not logged in'
                ]);
            } else {
                echo json_encode([
                    'success' => true,
                    'username' => $username
                ]);
            }
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Login code not found in account table'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Auth not found in users table'
        ]);
    }

    // Close statement and connection
    $stmt->close();
    $mysqli->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Missing auth parameter'
    ]);
}
?>
