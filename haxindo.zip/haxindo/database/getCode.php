<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');

$data = json_decode(file_get_contents("php://input"));

if (isset($data->login_code)) {
    $login_code = $data->login_code;

    $host = "localhost";
    $user = "root";
    $pass = ""; 
    $db = "indohax";

    $mysqli = new mysqli($host, $user, $pass, $db);

    if ($mysqli->connect_error) {
        die("Koneksi database gagal: " . $mysqli->connect_error);
    }

    $query = "SELECT * FROM account WHERE login_code = ?";
    $stmt = $mysqli->prepare($query);
    $stmt->bind_param("s", $login_code);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode([
            'success' => true,
            'data' => [
                'id' => $row['id'], // Return account ID
                'login_code' => $row['login_code'],
                'username' => $row['username']
            ]
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Login code not found'
        ]);
    }

    $stmt->close();
    $mysqli->close();
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Missing login_code parameter'
    ]);
}
?>
