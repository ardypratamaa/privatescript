<?php 
include 'header.php'; 
include 'subnavbar.php'; 
include 'effect.php'; 
require 'database/connect.php'; 

// Fetch user statistics if the user is logged in
$userStats = null;
if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];
    
    // Fetch the login code from the account table
    $selectStmt = $mysqli->prepare("SELECT login_code FROM account WHERE username = ?");
    $selectStmt->bind_param('s', $username);
    $selectStmt->execute();
    $selectResult = $selectStmt->get_result();
    $userData = $selectResult->fetch_assoc();
    $loginCode = $userData['login_code'];

    // Fetch user statistics from the users table using the login code
    $statsStmt = $mysqli->prepare("SELECT playername, win, lose, goals, assist, stars, matches_played, clean_sheet, clean_sheet_percentage FROM users WHERE login_code = ?");
    $statsStmt->bind_param('s', $loginCode);
    $statsStmt->execute();
    $statsResult = $statsStmt->get_result();
    $userStats = $statsResult->fetch_assoc();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Indonesia Haxball League</title>
    <style>
        .stats-container {
            width: 90%;
            max-width: 1000px;
            margin: 40px auto;
            padding: 20px;
            background-color: #f4f4f4;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .stats-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .stats-table {
            width: 100%;
            border-collapse: collapse;
        }

        .stats-table th, .stats-table td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: center;
            box-sizing: border-box;
        }

        .stats-table th {
            background-color: #133B5C;
            color: white;
        }

        .stats-table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<div class="stats-container">
    <h2 class="stats-header">Player Statistics</h2>
    <?php if ($userStats): ?>
    <table class="stats-table">
        <tr>
            <th>Ingame Nick</th>
            <th>Wins</th>
            <th>Losses</th>
            <th>Goals</th>
            <th>Assists</th>
            <th>Stars</th>
            <th>Matches Played</th>
            <th>Clean Sheets</th>
            <th>Clean Sheet Percentage</th>
        </tr>
        <tr>
            <td><?php echo htmlspecialchars($userStats['playername']); ?></td>
            <td><?php echo htmlspecialchars($userStats['win']); ?></td>
            <td><?php echo htmlspecialchars($userStats['lose']); ?></td>
            <td><?php echo htmlspecialchars($userStats['goals']); ?></td>
            <td><?php echo htmlspecialchars($userStats['assist']); ?></td>
            <td><?php echo htmlspecialchars($userStats['stars']); ?></td>
            <td><?php echo htmlspecialchars($userStats['matches_played']); ?></td>
            <td><?php echo htmlspecialchars($userStats['clean_sheet']); ?></td>
            <td><?php echo htmlspecialchars($userStats['clean_sheet_percentage']); ?>%</td>
        </tr>
    </table>
    <?php else: ?>
    <p>No statistics available. Please log in to view your stats.</p>
    <?php endif; ?>
</div>

</body>
</html>
