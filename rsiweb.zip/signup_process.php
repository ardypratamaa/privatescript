<?php
require 'database/connect.php'; // Skrip koneksi database Anda

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email']; // Ensure 'email' matches your table column name
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $terms = isset($_POST['terms']);
    $country = $_POST['country']; // Ensure 'country' matches your table column name

    if (!$terms) {
        header("Location: signup.php?error=You must accept the terms and conditions.");
        exit();
    }

    if ($password !== $confirm_password) {
        header("Location: signup.php?error=Passwords do not match.");
        exit();
    }

    // Check if the email already exists
    $stmt = $mysqli->prepare("SELECT * FROM account WHERE email = ?"); // Ensure 'email' matches your table column name
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        header("Location: signup.php?error=Email is already taken.");
        exit();
    }

    // No password hashing
    $stmt = $mysqli->prepare("INSERT INTO account (username, email, password, country) VALUES (?, ?, ?, ?)"); // Ensure 'country' matches your table column name
    $stmt->bind_param('ssss', $username, $email, $password, $country);

    if ($stmt->execute()) {
        header("Location: login.php?success=Account created successfully. Please login.");
        exit();
    } else {
        header("Location: signup.php?error=An error occurred. Please try again.");
        exit();
    }
}
?>
