<?php
require 'database/connect.php'; 

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username']; 
    $selectStmt = $mysqli->prepare("SELECT country, login_code FROM account WHERE username = ?");
    $selectStmt->bind_param('s', $username);
    $selectStmt->execute();
    $selectResult = $selectStmt->get_result();
    $userData = $selectResult->fetch_assoc();
   
    $userFlag = $userData['country'];
    $loginCode = $userData['login_code'];

    if (isset($_POST['reset_code'])) {
        $loginCode = generateLoginCode();
        $updateStmt = $mysqli->prepare("UPDATE account SET login_code = ? WHERE username = ?");
        $updateStmt->bind_param('ss', $loginCode, $username);
        $updateStmt->execute();
    } else {
        // Use the existing login code from the database
        $loginCode = $userData['login_code'];
    }
}

function generateLoginCode($length = 5) {
    return strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, $length));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sub Navbar</title>
    <style>
        .sub-navbar .sub-container-fluid {
            background-color: #133B5C;
            padding: 10px 0;
        }

        .sub-navbar .sub-container-fluid .sub-navbar-nav {
            display: flex;
            align-items: center;
            justify-content: flex-start;
            list-style-type: none;
            padding-left: 0;
        }

        .sub-navbar .sub-container-fluid .sub-nav-item {
            margin-right: 10px;
        }

        .sub-navbar .sub-container-fluid .sub-nav-link {
            color: #000;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .sub-navbar .sub-container-fluid .social-btn {
            display: inline-block;
            padding: 10px 20px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin-bottom: -15px;
        }

        .sub-navbar .sub-container-fluid .discord-btn {
            background-color: #7289da;
        }

        .sub-navbar .sub-container-fluid .discord-btn:hover {
            background-color: #5f73bc;
        }

        .sub-navbar .sub-container-fluid .tiktok-btn {
            background-color: black;
        }

        .sub-navbar .sub-container-fluid .tiktok-btn:hover {
            background-color: black;
        }

        .sub-navbar .sub-container-fluid .instagram-btn {
            background-color: #e4405f;
        }

        .sub-navbar .sub-container-fluid .instagram-btn:hover {
            background-color: #c72c4d;
        }

        .sub-navbar .sub-container-fluid .profile-btn {
            background-color: #36BA98;
            margin-left: 900px;
            display: <?php echo isset($_SESSION['username']) ? 'inline-block' : 'none'; ?>;
        }

        .sub-navbar .sub-container-fluid .profile-btn:hover {
            background-color: #36BA98;
        }
        .sub-navbar .sub-container-fluid .login-btn {
            background-color: #088395;
        }
        .flag-icon {
            width: 25px;
            height: auto;
            vertical-align: middle;
            margin-right: 8px;
        }
    </style>
</head>
<body>

<div class="sub-navbar">
    <div class="sub-container-fluid">
        <ul class="sub-navbar-nav">
            <li class="sub-nav-item">
                <a class="sub-nav-link social-btn discord-btn" href="https://discord.gg/EQg8HkQYAF" target="_blank">Discord</a>
            </li>
            <li class="sub-nav-item">
                <a class="sub-nav-link social-btn tiktok-btn" href="https://www.tiktok.com/@jellydrinkkkz" target="_blank">TikTok</a>
            </li>
            <li class="sub-nav-item">
                <a class="sub-nav-link social-btn instagram-btn" href="https://www.instagram.com/rsihaxball/" target="_blank">Instagram</a>
            </li>
            <li class="sub-nav-item">
                <?php if (isset($_SESSION['username'])) : ?>
                    <a class="sub-nav-link social-btn login-btn"><?php echo $loginCode; ?></a>
                <?php else: ?>
                    <a class="sub-nav-link social-btn login-btn">Login to get code</a>
                <?php endif; ?>
            </li>
            <li class="sub-nav-item">
                <?php if (isset($_SESSION['username'])) : ?>
                    <a class="sub-nav-link social-btn profile-btn" href="#">
                        <img src="assets/resources/flags/<?php echo htmlspecialchars($userFlag); ?>.svg" alt="" class="flag-icon">
                        <strong><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
                    </a>
                <?php endif; ?>
            </li>
            <li class="sub-nav-item">
                <?php if (isset($_SESSION['username'])) : ?>
                    <form method="post" action="">
                        <button type="submit" name="reset_code" class="sub-nav-link social-btn login-btn">Reset Code</button>
                    </form>
                <?php endif; ?>
            </li>
        </ul>
    </div>
</div>

</body>
</html>
