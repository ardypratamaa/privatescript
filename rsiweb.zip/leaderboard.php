<?php
include 'header.php';
include 'subnavbar.php';
include 'effect.php';

require 'database/connect.php';

$query = "SELECT playername, stars, flag, goals, assist, matches_played FROM users ORDER BY stars DESC LIMIT 50";
$result = $mysqli->query($query);

if (!$result) {
    die("Query error: " . $mysqli->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=1024">
    <title>Leaderboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            font-family: Helvetica, Arial, sans-serif;
        }
        body {
            background: #232323;
        }
        input[type=text] {
            padding: 10px;
            width: 100%;
            font-size: 14px;
            font-family: inherit;
            line-height: 24px;
            color: #555;
            background-color: #f1f1f1;
            border: none;
            transition: all 0.2s ease;
            -webkit-transition: all 0.2s ease;
        }
        input[type=text] {
            background-color: rgba(0,0,0,0.1);
            border-radius: 4px;
            border: 2px solid rgba(0,0,0,0);
        }
    
        #leaderboard {
            padding: 50px;
        }
        .ladder-nav {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            background: #5055CB;
            padding: 10px 25px;
            border-radius: 10px;
            border: 1px solid #686EF9;
        }
        .ladder-title {
            flex: 2;
        }
        .ladder-search {
            flex: 1;
            padding-right: 25px;
            display: flex;
            justify-content: flex-end;
        }
        .ladder-title h1 {
            font-size: 20px;
            color: white !important;
            font-weight: bold;
            text-transform: uppercase;
            margin: 0;
        }
        .ladder-search input {
            color: white;
            margin-right: 10px;
        }
        .ladder-search input::-webkit-input-placeholder {
            color: #888DFF;
        }
        .ladder-search input::-moz-placeholder {
            color: #888DFF;
        }
        .ladder-search input:-ms-input-placeholder {
            color: #888DFF;
        }
        .ladder-search input:-moz-placeholder {
            color: #888DFF;
        }
    
        .leaderboard-results {
            text-align: left;
            border-collapse: collapse;
            width: 100%;
            background-color: #092635;
        }
        .leaderboard-results thead th {
            padding: 15px 25px;
            color: black;
            font-size: 14px;
            font-weight: bold;
            background-color: white;
            text-transform: uppercase;
        }
        .leaderboard-results tbody td {
            padding: 15px 25px;
            font-size: 16px;
            border-bottom: 5px solid #232323;
        }
        .leaderboard-results tbody td:nth-of-type(7) {
            font-weight: bold;
        }
        .leaderboard-results tbody tr:hover td {
            background: #1d1d1d;
        }
        .leaderboard-results tbody tr {
            color: white;
        }
        .leaderboard-results tbody tr:first-child {
            color: #ED9455;
        }
        .leaderboard-results tbody tr:nth-child(2) td {
            color: #ED9455;
        }
        .leaderboard-results tbody tr:nth-child(3) td {
            color: #ED9455;
        }
        .leaderboard-results tbody span {
            font-weight: bold;
            padding: 10px 15px;
            border-radius: 50%;
        }
        .leaderboard-results tbody tr:first-child span {
            background: #5055CB;
            color: white;
        }
        .leaderboard-results tbody tr span {
            background: #262626;
            color: #747474;
        }

        /* Popup Styles */
        .popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #ffffff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.25);
            z-index: 1000;
        }
        .popup-button {
            cursor: pointer;
            background-color: #5055CB;
            border: none;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 14px;
        }
        .popup-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }
        .popup .popup-option {
            display: block;
            margin: 10px 0;
            text-align: center;
            padding: 10px;
            background: #f1f1f1;
            cursor: pointer;
            border-radius: 5px;
            transition: background 0.3s;
        }
        .popup .popup-option:hover {
            background: #e0e0e0;
        }
    </style>
</head>
<body>
    <div class="container-wrap">
        <section id="leaderboard">
            <nav class="ladder-nav">
                <div class="ladder-title">
                    <h1>Stats</h1>
                </div>
                <div class="ladder-search">
                    <input type="text" id="search-leaderboard" class="live-search-box" placeholder="Search Team, Player...">
                    <button class="popup-button" id="filter-button">Filter</button>
                </div>
            </nav>
            <table id="rankings" class="leaderboard-results">
                <thead>
                    <tr>
                        <th>Rank</th>
                        <th>Country</th>
                        <th>Name</th>
                        <th>Stars</th>
                        <th>Goals</th>
                        <th>Assists</th>
                        <th>Games Played</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $rank = 1; 
                    $players = [];
                    while ($row = $result->fetch_assoc()) {
                        $players[] = $row; // Save player data in an array for resetting later
                        echo "<tr>";
                        echo "<td>" . $rank . "</td>"; 
                        echo "<td><img src='assets/resources/flags/" . htmlspecialchars($row['flag']) . ".svg' alt='Flag' style='width: 30px; height: auto;'></td>";
                        echo "<td>" . htmlspecialchars($row['playername']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['stars']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['goals']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['assist']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['matches_played']) . "</td>";
                        echo "</tr>";
                        $rank++; 
                    }
                    ?>
                </tbody>
            </table>
        </section>
    </div>

    <!-- Popup Overlay -->
    <div class="popup-overlay" id="popup-overlay"></div>

    <!-- Popup Window -->
    <div class="popup" id="filter-popup">
        <div class="popup-option" id="filter-most-goals">Most Goals</div>
        <div class="popup-option" id="filter-most-assists">Most Assists</div>
        <div class="popup-option" id="filter-most-games">Most Games</div>
        <div class="popup-option" id="filter-default">Default</div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", () => {
            const filterButton = document.getElementById("filter-button");
            const popupOverlay = document.getElementById("popup-overlay");
            const filterPopup = document.getElementById("filter-popup");
            const searchInput = document.getElementById("search-leaderboard");
            const tableBody = document.querySelector("#rankings tbody");
            const originalRows = Array.from(tableBody.getElementsByTagName("tr")); // Save original rows for reset

            // Show popup when filter button is clicked
            filterButton.addEventListener("click", () => {
                popupOverlay.style.display = "block";
                filterPopup.style.display = "block";
            });

            // Hide popup when clicking outside
            popupOverlay.addEventListener("click", () => {
                popupOverlay.style.display = "none";
                filterPopup.style.display = "none";
            });

            // Filter by most goals
            document.getElementById("filter-most-goals").addEventListener("click", () => {
                sortTable(4); // Column 4 is "Goals"
                closePopup();
            });

            // Filter by most assists
            document.getElementById("filter-most-assists").addEventListener("click", () => {
                sortTable(5); // Column 5 is "Assists"
                closePopup();
            });

            // Filter by most games
            document.getElementById("filter-most-games").addEventListener("click", () => {
                sortTable(6); // Column 6 is "Games Played"
                closePopup();
            });

            // Reset to default
            document.getElementById("filter-default").addEventListener("click", () => {
                resetTable(); // Reset the table to its original order
                closePopup();
            });

            // Search functionality
            searchInput.addEventListener("input", () => {
                const searchTerm = searchInput.value.toLowerCase();
                const filteredRows = originalRows.filter(row => {
                    const cells = row.getElementsByTagName("td");
                    return Array.from(cells).some(cell => 
                        cell.textContent.toLowerCase().includes(searchTerm)
                    );
                });

                tableBody.innerHTML = ""; // Clear current rows
                filteredRows.forEach(row => tableBody.appendChild(row)); // Append filtered rows
            });

            function closePopup() {
                popupOverlay.style.display = "none";
                filterPopup.style.display = "none";
            }

            function sortTable(n) {
                const table = document.getElementById("rankings");
                let rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;
                switching = true;
                dir = "desc";

                while (switching) {
                    switching = false;
                    rows = table.rows;

                    for (i = 1; i < (rows.length - 1); i++) {
                        shouldSwitch = false;
                        x = rows[i].getElementsByTagName("TD")[n];
                        y = rows[i + 1].getElementsByTagName("TD")[n];

                        if (dir === "asc") {
                            if (parseInt(x.innerHTML) > parseInt(y.innerHTML)) {
                                shouldSwitch = true;
                                break;
                            }
                        } else if (dir === "desc") {
                            if (parseInt(x.innerHTML) < parseInt(y.innerHTML)) {
                                shouldSwitch = true;
                                break;
                            }
                        }
                    }

                    if (shouldSwitch) {
                        rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
                        switching = true;
                        switchcount++;
                    } else {
                        if (switchcount === 0 && dir === "desc") {
                            dir = "asc";
                            switching = true;
                        }
                    }
                }
            }

            function resetTable() {
                tableBody.innerHTML = ""; // Clear current rows

                originalRows.forEach(row => {
                    tableBody.appendChild(row); // Re-add the original rows in their initial order
                });
            }
        });
    </script>
</body>
</html>
