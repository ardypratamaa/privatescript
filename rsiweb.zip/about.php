<?php
include 'header.php';
include 'subnavbar.php';
include 'effect.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=1024">
    <title>About Us</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            font-family: Helvetica, Arial, sans-serif;
        }
        body {
            background: #232323;
            color: #f1f1f1;
            padding: 20px;
        }
        .container-wrap {
            max-width: 1000px;
            margin: auto;
        }
        .section {
            background: #1c1c1c;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .section h2 {
            font-size: 24px;
            color: #5055CB;
            margin-bottom: 15px;
        }
        .section p {
            font-size: 16px;
            line-height: 1.5;
        }
        .section img {
            width: 100%;
            height: auto;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="container-wrap">
        <section class="section">
            <h2>About Haxball</h2>
            <p>
                Haxball is an online multiplayer game that combines elements of soccer and air hockey. It features a minimalistic design with a 2D top-down view where players control a disk-like ball on a rectangular field. The primary objective is to score goals by maneuvering the ball into the opponent's net. The game is renowned for its simple yet addictive gameplay, offering both casual and competitive experiences. Players can join various game rooms, participate in tournaments, and engage in dynamic, fast-paced matches with friends and other players around the world.
            </p>
            <!-- <img src="assets/img/haxball.jpg" alt="Haxball Game"> -->
        </section>
        <section class="section">
            <h2>About RSI</h2>
            <p>
                RSI or (Real Soccer Indonesia) is a Haxball Community from Indonesia, RSI have some game-mode like Real Soccer, Futsal, Volleyball, Cop & Robber, Penalty, Powerball, etc. RSI have lead Real Soccer League last time and create many Events like Euro Futsal & Copa Futsal Competition.
            </p>
            <!-- <img src="assets/img/RSI_LOGO.png" alt="RSI Community"> -->
        </section>
    </div>
</body>
</html>
