<?php
function generateLoginCode($length = 5) {
    return strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, $length));
}
?>
