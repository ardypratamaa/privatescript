<?php
require 'database/connect.php';
session_start(); // Ensure session is started

if (isset($_SESSION['username'])) {
    $username = $_SESSION['username'];

    if ($_POST['action'] === 'reset') {
        // Generate a new login code
        $newLoginCode = generateLoginCode();
        
        // Update the database with the new code
        $updateStmt = $mysqli->prepare("UPDATE account SET login_code = ? WHERE username = ?");
        $updateStmt->bind_param('ss', $newLoginCode, $username);
        if ($updateStmt->execute()) {
            echo json_encode(['success' => true, 'newLoginCode' => $newLoginCode]);
        } else {
            echo json_encode(['success' => false]);
        }
        $updateStmt->close();
    }
}

function generateLoginCode($length = 5) {
    return strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, $length));
}

$mysqli->close();
?>
