<?php
require 'database/connect.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $auth = $_POST['username'];
    $loginCode = $_POST['loginCode'];

   
    $stmt = $mysqli->prepare("SELECT * FROM account WHERE login_code = ? AND username = ?");
    $stmt->bind_param('ss', $loginCode, $username);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user) {
        
        $newLoginCode = generateLoginCode();
        $stmt = $mysqli->prepare("UPDATE account SET login_code = ? WHERE username = ?");
        $stmt->bind_param('ss', $newLoginCode, $username);
        $stmt->execute();

        echo json_encode(['valid' => true, 'stats' => ['stars' => $user['stars']], 'newLoginCode' => $newLoginCode]);
    } else {
        echo json_encode(['valid' => false]);
    }
}

function generateLoginCode($length = 5) {
    return strtoupper(substr(md5(uniqid(mt_rand(), true)), 0, $length));
}
?>
